import React from 'react';
import { motion } from 'framer-motion';
import { TypeAnimation } from 'react-type-animation';
import { Github, Linkedin, FileText, Cloud, Database, Terminal } from 'lucide-react';

const Hero = () => {
  return (
    <section className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 hero-gradient" />
      
      <div className="container mx-auto px-4 pt-32 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto text-center"
        >
          <div className="mb-8">
            <img
              src="/profile.jpg"
              alt="Gopichand"
              className="w-40 h-40 rounded-full mx-auto mb-6 glass neon-glow object-cover border-4 border-neon-primary/20"
            />
            <h1 className="text-4xl md:text-6xl font-bold mb-4 neon-text bg-clip-text text-transparent bg-gradient-to-r from-neon-primary via-neon-secondary to-neon-accent">
              <TypeAnimation
                sequence={[
                  'Hi, I\'m Gopichand',
                  1000,
                  'AWS Cloud Engineer',
                  1000,
                  'DevOps Engineer',
                  1000,
                ]}
                wrapper="span"
                speed={50}
                repeat={Infinity}
              />
            </h1>
            <p className="text-xl text-gray-400 mb-8">
              Transforming ideas into scalable cloud solutions
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <motion.a
              href="#"
              className="glass px-6 py-3 rounded-full flex items-center gap-2 hover:neon-glow hover:bg-white/10 transition-all duration-300"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <FileText className="w-5 h-5 text-neon-primary" />
              Download Resume
            </motion.a>
            <motion.a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="glass px-6 py-3 rounded-full flex items-center gap-2 hover:neon-glow hover:bg-white/10 transition-all duration-300"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Github className="w-5 h-5 text-neon-secondary" />
              GitHub
            </motion.a>
            <motion.a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="glass px-6 py-3 rounded-full flex items-center gap-2 hover:neon-glow hover:bg-white/10 transition-all duration-300"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Linkedin className="w-5 h-5 text-neon-accent" />
              LinkedIn
            </motion.a>
          </div>
        </motion.div>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2">
          <div className="flex gap-8">
            <Cloud className="w-8 h-8 animate-float text-neon-primary" />
            <Database className="w-8 h-8 animate-float [animation-delay:1s] text-neon-secondary" />
            <Terminal className="w-8 h-8 animate-float [animation-delay:2s] text-neon-accent" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;